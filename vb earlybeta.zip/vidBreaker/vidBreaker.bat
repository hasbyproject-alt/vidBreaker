@echo off
python "data\pyf.py"
pause